package com.capston.hari;

public class NotifyData {
    public static String room;
    public static String Title;
    public static String User;
    public static String contents;
    public static String date;
    public static String money;
    public static String use;
}
