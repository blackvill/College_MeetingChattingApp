package com.capston.hari;

public class CardData {
    private String money;
    private String room_number;
    private String use;
    private String date;

    public String getMoney() { return money; }
    public void setMoney(String money) { this.money = money; }

    public String getRoom_number() { return room_number; }
    public void setRoom_number(String room_number) { this.room_number = room_number; }

    public String getUse() { return use; }
    public void setUse(String use) { this.use = use; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}