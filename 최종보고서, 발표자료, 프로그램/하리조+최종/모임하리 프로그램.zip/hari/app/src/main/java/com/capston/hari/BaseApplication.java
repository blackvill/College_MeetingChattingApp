package com.capston.hari;

import android.app.Application;

public class BaseApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Foreground.init(this);
    }
}
