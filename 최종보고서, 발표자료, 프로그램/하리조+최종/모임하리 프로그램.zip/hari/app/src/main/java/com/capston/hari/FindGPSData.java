package com.capston.hari;

public class FindGPSData {
    private String place_name;
    private String road_address_name;
    private String phone;
    private double x;
    private double y;

    public String getPlace_name() { return place_name; }
    public void setPlace_name(String place_name) { this.place_name = place_name; }

    public String getRoad_address_name() { return road_address_name; }
    public void setRoad_address_name(String road_address_name) { this.road_address_name = road_address_name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }

    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
}
